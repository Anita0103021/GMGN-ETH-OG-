// ── OG Scanner Content Script for GMGN ────────────────────────
'use strict';

// ── 工具函数 ────────────────────────────────────────────────────
function escHtml(s) {
  if (!s) return '';
  return String(s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;')
    .replace(/'/g,'&#39;');
}

function fmtNum(n) {
  if (!n || n === 0) return '—';
  if (n >= 1e9) return '$' + (n/1e9).toFixed(2) + 'B';
  if (n >= 1e6) return '$' + (n/1e6).toFixed(2) + 'M';
  if (n >= 1e3) return '$' + (n/1e3).toFixed(1) + 'K';
  return '$' + Math.round(n);
}

function fmtDate(ts) {
  if (!ts) return '—';
  return new Date(ts).toLocaleDateString('zh-CN', { year:'numeric', month:'short', day:'numeric' });
}

// ── 从 GMGN URL 解析链和合约地址 ────────────────────────────────
// GMGN URL 格式:
//   https://gmgn.ai/eth/token/0x...
//   https://gmgn.ai/bsc/token/0x...
//   https://gmgn.ai/eth/token/SYMBOL_0x...  (带 symbol 前缀)
// 支持的链（只有 eth）
const SUPPORTED_CHAINS = ['eth'];

function parseGmgnUrl(url) {
  const m = url.match(/gmgn\.ai\/(eth|bsc|sol|base|blast|ton)\/token\/(?:[^_]+_)?(0x[0-9a-fA-F]{40})/i);
  if (!m) return null;
  return { chain: m[1].toLowerCase(), address: m[2] };
}

function isOnGmgn(url) {
  return /gmgn\.ai\//.test(url);
}

function isSupportedChain(chain) {
  return SUPPORTED_CHAINS.includes(chain);
}

// ── GoPlus 安全解析 ─────────────────────────────────────────────
function parseSec(s) {
  return {
    isHoneypot:    s.is_honeypot === '1',
    cannotSell:    s.cannot_sell_all === '1',
    buyTax:        parseFloat(s.buy_tax || 0),
    sellTax:       parseFloat(s.sell_tax || 0),
    ownerRenounced:!s.owner_address || s.owner_address === '0x0000000000000000000000000000000000000000',
    lpLocked:      s.lp_holders ? lpLocked(s.lp_holders) : null,
    lpPct:         s.lp_holders ? lpPct(s.lp_holders) : 0,
    mintable:      s.is_mintable === '1',
    proxy:         s.is_proxy === '1',
    blacklist:     s.is_blacklisted === '1',
    hiddenOwner:   s.hidden_owner === '1',
    openSource:    s.is_open_source === '1',
    selfDestruct:  s.selfdestruct === '1',
    holderCount:   parseInt(s.holder_count || 0),
  };
}

function lpLocked(h) {
  try { const a = typeof h==='string'?JSON.parse(h):h; return a.some(x=>x.is_locked===1); }
  catch(e) { return null; }
}
function lpPct(h) {
  try { const a = typeof h==='string'?JSON.parse(h):h; return a.filter(x=>x.is_locked===1).reduce((s,x)=>s+parseFloat(x.percent||0),0)*100; }
  catch(e) { return 0; }
}
function calcRisk(s) {
  if (!s) return 'unknown';
  if (s.isHoneypot || s.cannotSell || s.hiddenOwner || s.selfDestruct) return 'danger';
  if (s.sellTax > 10 || s.buyTax > 10) return 'danger';
  if (!s.ownerRenounced || s.proxy || s.blacklist || s.mintable) return 'warn';
  if (s.lpLocked === false || s.sellTax > 5 || s.buyTax > 5) return 'warn';
  return 'safe';
}

// ── GoPlus 单地址请求 ───────────────────────────────────────────
async function fetchGoPlus(address, chainId) {
  try {
    const url = `https://api.gopluslabs.io/api/v1/token_security/${chainId}?contract_addresses=${address.toLowerCase()}`;
    const res = await fetch(url);
    const data = await res.json();
    if (!data.result) return null;
    const key = Object.keys(data.result)[0];
    return key ? parseSec(data.result[key]) : null;
  } catch(e) { return null; }
}

// ── DexScreener 搜索（按名字找 OG）──────────────────────────────
async function searchOG(symbol, chains) {
  try {
    const res = await fetch(`https://api.dexscreener.com/latest/dex/search?q=${encodeURIComponent(symbol)}`);
    if (!res.ok) return [];
    const data = await res.json();
    const pairs = (data.pairs || []).filter(p => chains.includes(p.chainId));
    const seen = new Map();
    for (const p of pairs) {
      const addr = p.baseToken?.address?.toLowerCase();
      if (!addr) continue;
      const n = (p.baseToken?.name || '').toLowerCase();
      const s = (p.baseToken?.symbol || '').toLowerCase();
      const kw = symbol.toLowerCase();
      if (!n.includes(kw) && !s.includes(kw)) continue;
      const ts = p.pairCreatedAt || Infinity;
      if (!seen.has(addr) || ts < seen.get(addr).pairCreatedAt) seen.set(addr, p);
    }
    return [...seen.values()].sort((a,b) => (a.pairCreatedAt||Infinity)-(b.pairCreatedAt||Infinity));
  } catch(e) { return []; }
}

// ── DexScreener 按地址获取代币信息 ─────────────────────────────
async function fetchTokenInfo(address) {
  try {
    const res = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${address}`);
    const data = await res.json();
    return (data.pairs && data.pairs[0]) || null;
  } catch(e) { return null; }
}

// ── 面板 HTML 生成 ──────────────────────────────────────────────
function buildPanel() {
  const div = document.createElement('div');
  div.id = 'og-scanner-panel';
  div.innerHTML = `
    <div class="og-resize-handle og-rh-n"  data-dir="n"></div>
    <div class="og-resize-handle og-rh-s"  data-dir="s"></div>
    <div class="og-resize-handle og-rh-w"  data-dir="w"></div>
    <div class="og-resize-handle og-rh-e"  data-dir="e"></div>
    <div class="og-resize-handle og-rh-nw" data-dir="nw"></div>
    <div class="og-resize-handle og-rh-ne" data-dir="ne"></div>
    <div class="og-resize-handle og-rh-sw" data-dir="sw"></div>
    <div class="og-resize-handle og-rh-se" data-dir="se"></div>
    <div id="og-scanner-header">
      <span class="eth-logo" style="flex-shrink:0;width:18px;height:18px;display:inline-flex;align-items:center;">
        <svg viewBox="0 0 32 32" width="18" height="18" xmlns="http://www.w3.org/2000/svg">
          <polygon points="16,2 16,12.5 25,16.5" fill="rgba(255,255,255,0.5)"/>
          <polygon points="16,2 7,16.5 16,12.5" fill="#ffffff"/>
          <polygon points="16,12.5 25,16.5 16,21" fill="#ffffff"/>
          <polygon points="16,12.5 7,16.5 16,21" fill="rgba(255,255,255,0.5)"/>
          <polygon points="16,22.5 25,18 16,30" fill="rgba(255,255,255,0.5)"/>
          <polygon points="16,22.5 7,18 16,30" fill="#ffffff"/>
        </svg>
      </span>
      <span class="title">以太OG查询</span>
      <span class="chain-pill" id="og-chain-pill">—</span>
      <div class="header-btns">
        <button class="hbtn" id="og-opacity-btn" title="透明度">
          <svg viewBox="0 0 20 20" width="14" height="14" xmlns="http://www.w3.org/2000/svg">
            <!-- 圆环 -->
            <circle cx="10" cy="10" r="4.5" fill="none" stroke="currentColor" stroke-width="1.5"/>
            <!-- 左半填充 -->
            <path d="M10,5.5 A4.5,4.5 0 0,0 10,14.5 Z" fill="currentColor"/>
            <!-- 光线 8条 -->
            <line x1="10" y1="1"  x2="10" y2="3"   stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <line x1="10" y1="17" x2="10" y2="19"  stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <line x1="1"  y1="10" x2="3"  y2="10"  stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <line x1="17" y1="10" x2="19" y2="10"  stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <line x1="3.2" y1="3.2"  x2="4.6" y2="4.6"  stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <line x1="15.4" y1="15.4" x2="16.8" y2="16.8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <line x1="16.8" y1="3.2"  x2="15.4" y2="4.6"  stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <line x1="4.6" y1="15.4"  x2="3.2" y2="16.8"  stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
        </button>
        <button class="hbtn" id="og-minimize-btn" title="最小化/展开">—</button>
      </div>
    </div>
    <div id="og-opacity-panel" style="display:none;">
      <div class="opacity-row">
        <span class="opacity-label">透明度</span>
        <input type="range" id="og-opacity-slider" min="20" max="100" value="100" step="5">
        <span class="opacity-val" id="og-opacity-val">100%</span>
      </div>
    </div>
    <div id="og-scanner-body">
      <div class="status-bar" id="og-status">正在识别当前代币...</div>
    </div>
  `;
  document.body.appendChild(div);

  // ── 常量 ───────────────────────────────────────────────────────
  const MIN_W    = 320, MAX_W = 680;
  const HEADER_H = 48;
  const MARGIN   = 16;
  const STORE_KEY = 'og_scanner_prefs';

  // localStorage 读写（扩展 content script 可直接访问页面 localStorage）
  function loadPrefs() {
    try { return JSON.parse(localStorage.getItem(STORE_KEY) || '{}'); } catch(e) { return {}; }
  }
  function savePrefs(obj) {
    try {
      const cur = loadPrefs();
      localStorage.setItem(STORE_KEY, JSON.stringify({...cur, ...obj}));
    } catch(e) {}
  }

  // ── 初始化位置（必须在 DOM 稳定后执行）───────────────────────
  function initPanelPosition() {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const prefs = loadPrefs();

    // 恢复上次宽高
    const w = Math.min(MAX_W, Math.max(MIN_W, prefs.w || 420));
    const h = Math.min(vh * 0.88, Math.max(200, prefs.h || 480));
    div.style.width  = w + 'px';
    div.style.height = h + 'px';
    div.style.overflow = 'hidden'; // body 自己处理滚动
    savedH = h; // 同步记忆高度

    // 恢复上次位置，没有则默认右下角
    const defLeft = vw - w - MARGIN;
    const defTop  = vh - h - MARGIN;
    const l = prefs.l !== undefined ? prefs.l : defLeft;
    const t = prefs.t !== undefined ? prefs.t : defTop;

    div.style.left   = Math.max(MARGIN, Math.min(vw - w - MARGIN, l)) + 'px';
    div.style.top    = Math.max(MARGIN, Math.min(vh - HEADER_H - MARGIN, t)) + 'px';
    div.style.right  = 'auto';
    div.style.bottom = 'auto';

    // 恢复折叠状态（在 minBtn 初始化之前，用标记，之后在 minBtn 绑定后再执行）
    div.dataset.restoreCollapsed = prefs.collapsed ? '1' : '0';
  }

  // ── 工具：确保 left/top 已设置（拖拽前调用）──────────────────
  function ensureLeftTop() {
    if (div.style.left && div.style.left !== 'auto') return;
    initPanelPosition();
  }

  // ── 工具：读取当前 left/top/width/height ─────────────────────
  function getPLTWH() {
    return {
      l: parseFloat(div.style.left)  || 0,
      t: parseFloat(div.style.top)   || 0,
      w: div.offsetWidth,
      h: div.offsetHeight,
    };
  }

  // ── 工具：把面板夹在屏幕内 ────────────────────────────────────
  function clamp() {
    const vw = window.innerWidth, vh = window.innerHeight;
    let l = parseFloat(div.style.left) || 0;
    let t = parseFloat(div.style.top)  || 0;
    const w = div.offsetWidth, h = div.offsetHeight;
    l = Math.max(MARGIN, Math.min(vw - w - MARGIN, l));
    const minVis = collapsed ? HEADER_H : h;
    t = Math.max(MARGIN, Math.min(vh - minVis - MARGIN, t));
    div.style.left = l + 'px';
    div.style.top  = t + 'px';
  }

  // ── 折叠/展开 ──────────────────────────────────────────────────
  const header = div.querySelector('#og-scanner-header');
  // arrow 已改为 minBtn，在下方初始化
  let collapsed = false;
  let savedH = loadPrefs().h || 480; // 从记忆读取，默认 480

  // 判断展开方向：
  // 面板中心在屏幕上半部 → 向下展开
  // 面板中心在屏幕下半部 → 向上展开
  function getExpandDir() {
    const panelTop    = parseFloat(div.style.top) || 0;
    const panelH      = collapsed ? HEADER_H : div.offsetHeight;
    const panelCenter = panelTop + panelH / 2;
    const vh          = window.innerHeight;
    return panelCenter < vh / 2 ? 'down' : 'up';
  }

  function collapse() {
    if (div.offsetHeight > HEADER_H) {
      savedH = div.offsetHeight;
      savePrefs({ h: savedH });
    }
    const dir = getExpandDir();
    div.dataset.dir = dir;

    if (dir === 'up') {
      // 向上展开模式：锁定底边，折叠时 top 下移到底边 - HEADER_H
      const bottom = parseFloat(div.style.top) + div.offsetHeight;
      div.style.top = (bottom - HEADER_H) + 'px';
    }
    // down 模式：top 不动，高度收缩到 HEADER_H

    div.style.height = HEADER_H + 'px';
    // 折叠时面板 overflow 交给内部 body 处理，外层只需 hidden
    div.style.overflow = 'hidden';
    if (dir === 'up') div.classList.add('dir-up');
    else              div.classList.remove('dir-up');
    if(minBtn) minBtn.textContent = '＋';
    collapsed = true;
    savePrefs({ collapsed: true });
    clamp();
  }

  function expand() {
    const dir = div.dataset.dir || getExpandDir();
    const vh  = window.innerHeight;
    let h;

    if (dir === 'up') {
      const bottom = parseFloat(div.style.top) + HEADER_H;
      const avail  = bottom - MARGIN;
      h = avail >= savedH ? savedH : Math.max(200, avail);
      div.style.top = (bottom - h) + 'px';
    } else {
      const top   = parseFloat(div.style.top) || 0;
      const avail = vh - top - MARGIN;
      h = avail >= savedH ? savedH : Math.max(200, avail);
    }

    div.style.height = h + 'px';
    div.style.overflow = 'hidden'; // body 内部滚动
    if (dir === 'up') div.classList.add('dir-up');
    else              div.classList.remove('dir-up');
    if(minBtn) minBtn.textContent = '—';
    collapsed = false;
    savePrefs({ collapsed: false });
    clamp();
    // 展开后滚动到顶部（无论 dir-up 还是 dir-down）
    const body = div.querySelector('#og-scanner-body');
    if (body) body.scrollTop = 0;
  }

  function toggleCollapse() {
    if (collapsed) expand(); else collapse();
  }

  // 最小化按钮
  const minBtn = div.querySelector('#og-minimize-btn');
  const opBtn  = div.querySelector('#og-opacity-btn');
  const opPanel = div.querySelector('#og-opacity-panel');
  const opSlider = div.querySelector('#og-opacity-slider');
  const opVal    = div.querySelector('#og-opacity-val');

  minBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleCollapse();
    minBtn.textContent = collapsed ? '＋' : '—';
    if (collapsed && opPanel.style.display !== 'none') {
      opPanel.style.display = 'none';
    }
  });

  // 透明度按钮 & 滑块
  opBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    opPanel.style.display = opPanel.style.display === 'none' ? 'block' : 'none';
  });

  opSlider.addEventListener('input', () => {
    const v = opSlider.value;
    div.style.opacity = v / 100;
    opVal.textContent = v + '%';
  });

  // ── 事件委托：GMGN 跳转 + 复制 CA ──────────────────────────────
  div.addEventListener('click', (e) => {
    if (e.target.closest('.hbtn')) return; // 按钮自己处理
    if (e.target.closest('#og-opacity-panel')) return; // 透明度面板内部不传播
    if (e.target.closest('#og-scanner-header')) return; // header 区域

    const gmgnBtn  = e.target.closest('[data-gmgn]');
    const copyBtn  = e.target.closest('[data-copy]');

    if (gmgnBtn) {
      e.stopPropagation();
      const url = gmgnBtn.dataset.gmgn;
      if (url) window.location.href = url;
      return;
    }
    if (copyBtn) {
      e.stopPropagation();
      const text = copyBtn.dataset.copy;
      if (!text) return;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text)
          .then(() => flashBtn(copyBtn, '已复制 ✓'))
          .catch(() => fallbackCopy(text, copyBtn));
      } else {
        fallbackCopy(text, copyBtn);
      }
    }
  });

  function flashBtn(btn, msg) {
    const orig = btn.textContent;
    btn.textContent = msg;
    setTimeout(() => btn.textContent = orig, 1500);
  }

  // ── 拖拽移动（header mousedown）──────────────────────────────
  let isDragging = false;

  header.addEventListener('mousedown', (e) => {
    if (e.button !== 0) return;
    if (e.target.closest('.og-resize-handle')) return;
    ensureLeftTop();

    const { l, t } = getPLTWH();
    const sx = e.clientX, sy = e.clientY;
    isDragging = false;

    const onMove = (e) => {
      const dx = e.clientX - sx, dy = e.clientY - sy;
      if (!isDragging && Math.abs(dx)+Math.abs(dy) > 4) {
        isDragging = true;
        div.classList.add('dragging');
        header.style.cursor = 'grabbing';
      }
      if (!isDragging) return;
      const vw = window.innerWidth, vh = window.innerHeight;
      const pw = div.offsetWidth,  ph = div.offsetHeight;
      div.style.left = Math.max(MARGIN, Math.min(vw - pw - MARGIN, l+dx)) + 'px';
      // 底部边界：保证至少 HEADER_H 可见（折叠）或整个面板在屏幕内（展开）
      const minVisible = collapsed ? HEADER_H : ph;
      div.style.top  = Math.max(MARGIN, Math.min(vh - minVisible - MARGIN, t+dy)) + 'px';
    };

    const onUp = (e) => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup',   onUp);
      div.classList.remove('dragging');
      header.style.cursor = 'grab';
      if (isDragging) {
        e.stopImmediatePropagation();
        isDragging = false;
        savePrefs({ l: parseFloat(div.style.left), t: parseFloat(div.style.top) });
        // 拖拽结束后立即更新展开方向 class，下次展开方向正确
        const newDir = getExpandDir();
        div.dataset.dir = newDir;
        if (newDir === 'up') div.classList.add('dir-up');
        else                 div.classList.remove('dir-up');
      }
    };

    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup',   onUp);
  });

  // ── 8方向 Resize ──────────────────────────────────────────────
  div.querySelectorAll('.og-resize-handle').forEach(handle => {
    handle.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      e.stopPropagation();
      ensureLeftTop();

      const dir = handle.dataset.dir;
      const sx = e.clientX, sy = e.clientY;
      const { l: sl, t: st, w: sw, h: sh } = getPLTWH();

      const onMove = (e) => {
        const dx = e.clientX - sx, dy = e.clientY - sy;
        let nl = sl, nt = st, nw = sw, nh = sh;
        const vw = window.innerWidth, vh = window.innerHeight;

        if (dir.includes('e')) nw = Math.min(MAX_W, Math.max(MIN_W, sw + dx));
        if (dir.includes('s')) nh = Math.min(window.innerHeight * 0.9, Math.max(HEADER_H + 100, sh + dy));
        if (dir.includes('w')) {
          const rawW = sw - dx;
          nw = Math.min(MAX_W, Math.max(MIN_W, rawW));
          nl = sl + (sw - nw); // 锚定右边
        }
        if (dir.includes('n')) {
          const rawH = sh - dy;
          nh = Math.min(window.innerHeight * 0.9, Math.max(HEADER_H + 100, rawH));
          nt = st + (sh - nh); // 锚定底边
        }

        // 边界保护
        nl = Math.max(0, Math.min(vw - MIN_W, nl));
        nt = Math.max(0, Math.min(vh - HEADER_H, nt));

        div.style.left  = nl + 'px';
        div.style.top   = nt + 'px';
        div.style.width = nw + 'px';
        savePrefs({ w: nw }); // 持久化宽度
        if (!collapsed) {
          div.style.height = nh + 'px';
          savedH = nh;
          savePrefs({ h: savedH, w: nw }); // 实时持久化尺寸
        }
        // 折叠状态：只改宽度，高度锁定为 HEADER_H
      };

      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup',   onUp);
        div.style.cursor = '';
      };

      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup',   onUp);
    });
  });

  // 延迟初始化位置，等浏览器渲染好再计算尺寸
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      initPanelPosition();
      // 恢复折叠状态（此时 minBtn 已绑定）
      if (div.dataset.restoreCollapsed === '1') {
        collapse();
      }
    });
  });

  return div;
}

function fallbackCopy(text, btn) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.cssText = 'position:fixed;opacity:0;top:0;left:0;';
  document.body.appendChild(ta);
  ta.focus(); ta.select();
  try {
    document.execCommand('copy');
    if (btn) {
      const orig = btn.textContent;
      btn.textContent = '已复制 ✓';
      setTimeout(() => btn.textContent = orig, 1500);
    }
  } catch(e) {}
  document.body.removeChild(ta);
}

// ── 渲染当前代币安全信息 ────────────────────────────────────────
function renderCurrentToken(pair, sec, chainName, address) {
  const name = escHtml(pair?.baseToken?.name || '未知');
  const sym  = escHtml(pair?.baseToken?.symbol || '?');
  const imgUrl = pair?.info?.imageUrl || null;
  const mc  = fmtNum(pair?.fdv || pair?.marketCap || 0);
  const liq = fmtNum(pair?.liquidity?.usd || 0);
  const risk = calcRisk(sec);

  const iconHtml = imgUrl
    ? `<img src="${escHtml(imgUrl)}" alt="${sym}" data-initials="${escHtml((pair?.baseToken?.symbol||'??').slice(0,2).toUpperCase())}">`
    : `<div class="tok-icon">${escHtml((pair?.baseToken?.symbol||'??').slice(0,2).toUpperCase())}</div>`;

  const chainLabel = chainName === 'eth' ? 'Ethereum' : 'BSC';
  const chainId    = chainName === 'eth' ? '1' : '56';

  // 安全摘要芯片
  let secChips = '';
  if (sec) {
    const honey = sec.isHoneypot || sec.cannotSell;
    const lpTxt = sec.lpLocked === null ? '未知' : sec.lpLocked ? `锁 ${sec.lpPct.toFixed(0)}%` : '未锁';
    const items = [
      { label:'貔貅', val: honey ? '是' : '否', cls: honey ? 'danger':'safe' },
      { label:'权限', val: sec.ownerRenounced ? '已放弃':'未放弃', cls: sec.ownerRenounced?'safe':'warn' },
      { label:'池子', val: lpTxt, cls: sec.lpLocked===null?'unk':sec.lpLocked?'safe':'warn' },
      { label:'卖税', val: sec.sellTax+'%', cls: sec.sellTax>10?'danger':sec.sellTax>5?'warn':'safe' },
      { label:'买税', val: sec.buyTax+'%',  cls: sec.buyTax>10?'danger':sec.buyTax>5?'warn':'safe' },
      { label:'增发', val: sec.mintable?'是':'否', cls: sec.mintable?'danger':'safe' },
    ];
    secChips = `<div class="sec-summary">${items.map(i=>`
      <div class="sec-chip">
        <span class="sc-label">${i.label}</span>
        <span class="sc-val ${i.cls}">${i.val}</span>
      </div>`).join('')}</div>`;
  } else {
    secChips = `<div class="sec-loading">⏳ 正在获取安全数据...</div>`;
  }

  const riskBadge = !sec ? '<span class="badge b-gray">检测中</span>'
    : risk==='danger' ? '<span class="badge b-danger">⚠ 高危</span>'
    : risk==='warn'   ? '<span class="badge b-warn">⚡ 注意</span>'
    : '<span class="badge b-safe">✓ 较安全</span>';

  const dexUrl = `https://dexscreener.com/${chainName==='eth'?'ethereum':'bsc'}/${address}`;
  const gpUrl  = `https://gopluslabs.io/token-security/${chainId}/${address}`;
  const scanUrl = chainName==='eth'
    ? `https://etherscan.io/address/${address}`
    : `https://bscscan.com/address/${address}`;

  return `
    <div class="current-token-bar">
      ${iconHtml}
      <div style="flex:1;min-width:0;">
        <div class="tok-name">${name} ${riskBadge}</div>
        <div class="tok-addr">${address.slice(0,8)}...${address.slice(-6)}</div>
      </div>
      <div style="text-align:right;flex-shrink:0;">
        <div style="font-size:11px;color:#a1a1aa;">MC ${mc}</div>
        <div style="font-size:11px;color:#71717a;">流动性 ${liq}</div>
      </div>
    </div>
    ${secChips}
    <div style="display:flex;gap:5px;margin-bottom:8px;flex-wrap:wrap;">
      <a class="action-btn btn-link" href="${dexUrl}" target="_blank">DexScreener ↗</a>
      <a class="action-btn btn-link" href="${gpUrl}" target="_blank">GoPlus ↗</a>
      <a class="action-btn btn-link" href="${scanUrl}" target="_blank">${chainName==='eth'?'Etherscan':'BscScan'} ↗</a>
    </div>
    <hr class="divider">`;
}

// ── 渲染 OG 结果列表 ────────────────────────────────────────────
function renderOgList(tokens, currentAddr) {
  if (!tokens.length) return '<div class="status-bar">未找到同名 OG 代币</div>';

  return tokens.slice(0,5).map((p, i) => {
    const addr    = p.baseToken?.address || '';
    const addrLow = addr.toLowerCase();
    const isCurrent = addrLow === currentAddr.toLowerCase();
    const isOG    = i === 0;
    const name    = escHtml(p.baseToken?.name || '—');
    const sym     = escHtml(p.baseToken?.symbol || '?');
    const initials = escHtml((p.baseToken?.symbol||'??').slice(0,2).toUpperCase());
    const imgUrl  = p.info?.imageUrl || null;
    const chain   = p.chainId;
    const chainId = chain === 'ethereum' ? '1' : '56';
    const chainName = chain === 'ethereum' ? 'eth' : 'bsc';
    const mc  = fmtNum(p.fdv || p.marketCap || 0);
    const liq = fmtNum(p.liquidity?.usd || 0);
    const created = fmtDate(p.pairCreatedAt || 0);
    const dexUrl  = p.url || `https://dexscreener.com/${chain}/${addr}`;
    const gmgnUrl = `https://gmgn.ai/${chainName}/token/${addr}`;
    const scanUrl = chain === 'ethereum'
      ? `https://etherscan.io/address/${addr}`
      : `https://bscscan.com/address/${addr}`;

    const iconHtml = imgUrl
      ? `<img src="${escHtml(imgUrl)}" alt="${sym}" data-initials="${initials}">`
      : `<div class="og-icon">${initials}</div>`;

    const chainBadge = chain === 'ethereum'
      ? '<span class="badge b-eth">ETH</span>'
      : '<span class="badge b-bsc">BSC</span>';

    const ogBadge  = isOG ? '<span class="badge b-og">🏆 OG</span>' : `<span class="badge b-gray">#${i+1}</span>`;
    const currBadge = isCurrent ? '<span class="badge b-safe">当前</span>' : '';

    const cardClass = `og-card${isOG?' is-og':''}`;

    // 跳转 GMGN 按钮（当前代币不显示）
    const gmgnBtn = !isCurrent
      ? `<button class="action-btn btn-primary" data-gmgn="${escHtml(gmgnUrl)}">→ 在GMGN打开</button>`
      : `<span class="badge b-safe" style="padding:4px 8px;">当前页面</span>`;

    const copyBtn = `<button class="action-btn btn-ghost" data-copy="${escHtml(addr)}">复制 CA</button>`;

    return `
      <div class="${cardClass}">
        <div class="og-card-header">
          ${iconHtml}
          <div style="flex:1;min-width:0;">
            <span class="og-name">${name}</span>
            <span class="og-sym">${sym}</span>
          </div>
        </div>
        <div class="og-badges">${ogBadge}${chainBadge}${currBadge}<span class="badge b-gray">📅 ${created}</span></div>
        <div class="og-metrics">
          <div class="og-metric"><div class="ml">市值</div><div class="mv">${mc}</div></div>
          <div class="og-metric"><div class="ml">流动性</div><div class="mv">${liq}</div></div>
        </div>
        <div class="sec-mini-grid" id="og-sec-mini-${addrLow}">
          <div style="grid-column:1/-1;" class="sec-loading">⏳ 检测中...</div>
        </div>
        <div class="og-actions">
          ${gmgnBtn}
          ${copyBtn}
          <a class="action-btn btn-link" href="${dexUrl}" target="_blank">Dex ↗</a>
        </div>
      </div>`;
  }).join('');
}

// ── 更新 OG 卡片安全数据 ────────────────────────────────────────
function updateOgCardSec(addr, sec) {
  const el = document.getElementById('og-sec-mini-' + addr.toLowerCase());
  if (!el) return;
  if (!sec) {
    el.innerHTML = `<div style="grid-column:1/-1;" class="sec-loading" style="color:#52525b;">安全数据不可用</div>`;
    return;
  }
  const risk  = calcRisk(sec);
  const honey = sec.isHoneypot || sec.cannotSell;
  const lpTxt = sec.lpLocked===null?'未知':sec.lpLocked?`锁 ${sec.lpPct.toFixed(0)}%`:'未锁';
  const items = [
    { label:'貔貅',  type: honey?'danger':'safe',            val: honey?'是':'否' },
    { label:'权限',  type: sec.ownerRenounced?'safe':'warn', val: sec.ownerRenounced?'已弃':'未弃' },
    { label:'池子',  type: sec.lpLocked===null?'unk':sec.lpLocked?'safe':'warn', val: lpTxt },
    { label:'卖税',  type: sec.sellTax>10?'danger':sec.sellTax>5?'warn':'safe',  val: sec.sellTax+'%' },
    { label:'买税',  type: sec.buyTax>10?'danger':sec.buyTax>5?'warn':'safe',    val: sec.buyTax+'%' },
    { label:'增发',  type: sec.mintable?'danger':'safe',     val: sec.mintable?'是':'否' },
  ];
  el.innerHTML = items.map(c => `
    <div class="sec-mini-item">
      <div class="smi-dot-row">
        <div class="smi-dot dot-${c.type}"></div>
        <span class="smi-label">${c.label}</span>
      </div>
      <span class="smi-val sv-${c.type}">${c.val}</span>
    </div>`).join('');

  // 更新卡片边框颜色
  const card = el.closest('.og-card');
  if (card) {
    card.classList.remove('danger','warn','safe');
    if (!card.classList.contains('is-og')) card.classList.add(risk);
  }
}

// ── 主流程 ──────────────────────────────────────────────────────
async function runScanner(info) {
  const panel  = document.getElementById('og-scanner-panel');
  const body   = document.getElementById('og-scanner-body');
  const pill   = document.getElementById('og-chain-pill');
  const status = document.getElementById('og-status');

  const chainName = info.chain;   // 'eth' | 'bsc'
  const chainId   = chainName === 'eth' ? 1 : 56;
  const address   = info.address;

  pill.textContent = chainName.toUpperCase();

  status.textContent = '正在获取代币信息...';

  // 并行：当前代币信息 + GoPlus 安全
  const [pair, sec] = await Promise.all([
    fetchTokenInfo(address),
    fetchGoPlus(address, chainId),
  ]);

  const sym    = pair?.baseToken?.symbol || '';
  const name   = pair?.baseToken?.name   || '';
  const keyword = sym || name;

  // 渲染当前代币块（无 sec 先占位）
  body.innerHTML = renderCurrentToken(pair, sec, chainName, address);

  // 如果有 sym，搜索同名 OG
  if (keyword) {
    const ogStatus = document.createElement('div');
    ogStatus.className = 'status-bar';
    ogStatus.textContent = `正在搜索「${keyword}」OG...`;
    body.appendChild(ogStatus);

    const tokens = await searchOG(keyword, ['ethereum','bsc']);

    ogStatus.remove();

    const ogTitle = document.createElement('div');
    ogTitle.className = 'og-section-title';
    ogTitle.textContent = `同名 OG 代币（共 ${tokens.length} 个）`;
    body.appendChild(ogTitle);

    const ogContainer = document.createElement('div');
    ogContainer.innerHTML = renderOgList(tokens, address);
    body.appendChild(ogContainer);

    // 异步批量拉 OG 列表安全数据（每次并发 5）
    const show = tokens.slice(0,5);
    const CONC = 3;
    for (let i = 0; i < show.length; i += CONC) {
      await Promise.allSettled(show.slice(i, i+CONC).map(async t => {
        const tAddr = t.baseToken?.address;
        const tChain = t.chainId === 'ethereum' ? 1 : 56;
        const s = await fetchGoPlus(tAddr, tChain);
        updateOgCardSec(tAddr, s);
      }));
    }
  } else {
    const noKw = document.createElement('div');
    noKw.className = 'status-bar';
    noKw.textContent = '无法获取代币符号，OG 搜索跳过';
    body.appendChild(noKw);
  }

  // 全局图片 fallback
  body.querySelectorAll('img[data-initials]').forEach(img => {
    img.onerror = function() {
      const d = document.createElement('div');
      d.className = img.closest('.current-token-bar') ? 'tok-icon' : 'og-icon';
      d.textContent = img.dataset.initials || '??';
      img.parentNode.replaceChild(d, img);
    };
  });
}

// ── URL 变化监听（GMGN 是 SPA）──────────────────────────────────
let lastUrl  = '';
let scanLock = false;

async function checkAndRun() {
  if (scanLock) return;
  const url  = location.href;
  const info = parseGmgnUrl(url);

  // ── 不在 GMGN 或不支持的链：隐藏面板 ─────────────────────────
  const panel = document.getElementById('og-scanner-panel');
  if (!isOnGmgn(url) || !info || !isSupportedChain(info.chain)) {
    if (panel) panel.style.display = 'none';
    lastUrl = url; // 更新 lastUrl 避免重复判断
    return;
  }

  // ── 支持的链：显示面板 ────────────────────────────────────────
  if (panel) panel.style.display = '';

  if (url === lastUrl) return;
  lastUrl  = url;
  scanLock = true;

  // 等待面板存在
  let p = document.getElementById('og-scanner-panel');
  if (!p) p = buildPanel();

  // 重置 body
  const body = document.getElementById('og-scanner-body');
  body.innerHTML = `<div class="status-bar" id="og-status">正在识别当前代币...</div>`;

  const pill = document.getElementById('og-chain-pill');
  if (pill) pill.textContent = info.chain.toUpperCase();

  try {
    await runScanner(info);
  } catch(e) {
    body.innerHTML += `<div class="error-bar">扫描出错：${escHtml(e.message)}</div>`;
  } finally {
    scanLock = false;
  }
}

// ── 初始化 ──────────────────────────────────────────────────────
function init() {
  // 监听 URL 变化（GMGN 是 React SPA，用 pushState/popstate）
  const origPush = history.pushState.bind(history);
  history.pushState = function(...args) {
    origPush(...args);
    setTimeout(checkAndRun, 600);
  };
  window.addEventListener('popstate', () => setTimeout(checkAndRun, 600));

  // 也用 MutationObserver 兜底（部分 SPA 用 hash 路由）
  const observer = new MutationObserver(() => {
    if (location.href !== lastUrl) checkAndRun();
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // 初次运行
  setTimeout(checkAndRun, 800);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
